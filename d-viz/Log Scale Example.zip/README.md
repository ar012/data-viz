Remark: Hover on the points, Click on the legent

This data is about the exports to China, United States, Brazil, India, Japan, Mexico and Russian Federation between 2000 and 2016, reporters are Africa, Asia excluding Hong Kong re-exports, Australia and New Zealand, Commonwealth of Independent States (CIS), including associate and former member States, Europe, European Union (28), Four East Asian traders, Middle East, North America, South and Central America and the Caribbean, Brazil, Japan, Mexico, Russian Federation.

All data comes from  [World Trade Organization: Network of world merchandise trade](http://stat.wto.org/StatisticalProgram/WSDBViewData.aspx?Language=E).